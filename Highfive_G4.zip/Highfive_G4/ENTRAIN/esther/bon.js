// déclaration de la fonction carrée
function carrée () {


let x=prompt("entrer un nombre");
 x=parseInt(x);
console.log(x);

 // mets le nombre au carrée s'il a 1chiffre
    
    if (x<10 ) {

       x=Math.pow(x,2);
       console.log(x);
    }

  // si cest un nombre a plusieur chiffre
  {
    //    x=Math.pow(x,2);
    //    traduire le nombre en chaîne de caractère
    let y = x.toString();
    let table = y.split('');
    console.log(table );
// por chaque élément du tableau faire le carrée

for (let i=0; i <table.length ;i++)
    {
        let z= Math.pow( table[i] , 2)
       
        //   console.log(table[i]);
        //   console.log(z);
        
        table[i]= z;
       
     let resultat= table.join ('');
     console.log( "le resultat" +resultat); 
       
    }
  }

}
carrée()  




/// Selon le nombre , la function récupère l