<script setup>
import { ref } from 'vue'
 const message = ref('Rendez moi dynamique!')

console.log(message.value) // "Hello World!"
message.value = 'Mis à jour'
// déclarez du state réactif ici.
  import { reactive } from 'vue'

const counter = reactive({
  count: 0
})

console.log(counter.count) // 0
counter.count++
</script>

<template>
<!--   <h1>Rendez moi dynamique!</h1>
   -->
<!--   <h1>{{ message }}</h1>
<p>Count à: {{ counter.count }}</p> -->
  <h1>{{ message.split('').reverse().join('') }}</h1>
</template>