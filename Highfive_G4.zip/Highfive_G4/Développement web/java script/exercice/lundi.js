// let element = document.getElementById ('app');
// console.log(element);
// element.style.backgroundColor="red";

// let element2 = document.querySelector('p')
//  element2.classList.add('fictive')
//  element2.addEventListener("click",domReady)

// console.log(element2)
// let element3 = document.querySelector('#text');
// console.log(element3);

// element4=   document.querySelectorAll ('p')
// console.log(element4);
// // let element4=getElementById
// element5 = document.querySelector ();
// //
// let firstelement= document.querySelector('p');
// firstelement.classList.add('fictive');


// function domReady (){
    
//     console.log( "domReady");
//     console.log("event");
// }
// document.addEventListener("DOMContentLoaded",domReady);


// let element6 = document.querySelector('ul');
// console.log(element6);
// element6.classList.add ('tove')
// element6.addEventListener("click", fly)

// function fly () {
//     element6.classList.toggle('tive')
// }

   
// document.addEventListener('keydown', function (event) 
//  {
//  console.log(event.key);
// }) 




let title = document.querySelector('h2'); 
let taille=200;

function action(event) 
 {
 console.log(event.code);
 if(event.code == 'Space')
    {
        title.style.fontSize =` ${++taille}px`
        
    }
    else  if( event.code=== 'KeyX') {
        document.removeEventListener('keydown', action)
        console.log("la touche" +event.code + "est appuyée");

    }
    else {
        console.log ("autre touche");
    }
}

document.addEventListener('keydown', action) 






















