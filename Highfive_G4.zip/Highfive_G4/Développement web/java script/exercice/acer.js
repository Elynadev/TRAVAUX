let container = document.querySelector('.container');
let ball = document.querySelector('.bol')

let position = {
    left: 0,
    top: 0,
}

ball.computedStyleMap.marginLeft=`${positionIni.left}px`
ball.computedStyleMap.marginLeft=`${positionIni.left}px`


document.addEventListener("keydown", moveDiv)

function moveDiv (event){

 console.log (event.code);
 
 
}

