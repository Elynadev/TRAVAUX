//  alert ("" +"calcul de longueur");
//  let longueur =prompt ("" + "entrer un nombre")
//  longueur



// let nombre = prompt ("" +"merci d'entre un nombre ") ;
// nombre= parseInt("" +nombre);

// if ("" +isFinite("" +nombre)){
//     let modulo = nombre % 2;
//     if("" +modulo=== 0) { 
//     alert("" +"votre entré est " +nombre+ "est un nombre pair")

// }
// }
// else  {
//     alert("" +"votre entré est " +nombre +"est un nombre pair")

// }
    
// else 

// {
//     alert("" + "merci d'entrer un nombre")
// }

// let nom= prompt("" + "entrer votre nom");
// let prenom = prompt ("" +"entrer votre prenom");

// let nom ;
// console.log("" +'bonjour' +nom);;


// nom= "elyn";
// console.log("" + nom);


// let x;
// console.log("x=" +x);
// let y;
// console.log("y=" +y);
// let z=0;
// console.log("z=" +z);

// x=1; //1
// console.log("x=" +x);
// x=2;  // 2
// console.log("x=" +x);
// y=5;  // 5
// console.log("y=" +y);
// x=9;  // 9
// console.log("x=" +x);


// let x=16;
// let y=2;
// console.log( x+ y); // 12

// console.log(x + y++); //13

// console.log(x + ++y); //13


// console.log(x + y--); //11

// console.log(x + --y); //11

// console.log(++x + --y); // 12

// console.log(x++ + --y); // 12

// console.log(--x + --y); // 10

// console.log(x-- + --y); // 10

// console.log(Math.sqrt(x));
// console.log(Math.pow(x, y));
// let random = Math.random(); // random peut être par exemple 0.712

// let nombre = 3.7;
// let arrondi1 = Math.round(nombre); // arrondi1 vaut 4
// let arrondi2 = Math.floor(nombre); // arrondi2 vaut 3
// let arrondi3 = Math.ceil(nombre); // arrondi3 vaut 4
// // console.log( arrondi1)
// let message = "Il a dit : \"Bonjour, monde !\"";
// console.log(message); // Affiche "Il a dit : "Bonjour, monde !""

// let message = 'Il a dit : \'Bonjour, monde !\'';
// console.log(message); // Affiche "Il a dit : 'Bonjour, monde !'"

// const listeCourses = "Liste des courses :\n\t- Pommes\n\t- Poires\n\t- Bananes";
//     console.log(listeCourses);

//     const yingYang = "Je suis " + "karaba." + " Le haut " + "et le bas.";
// console.log(yingYang)

// let salutation = "Bonjour";
// salutation += " tout";
// salutation += " le";
// salutation += " monde!";
// console.log(salutation);

// let produit = "ordinateur";
// let prix = 1200;
// let description = "Le prix du ";
// description += produit;
// description += " est de ";
// description += prix;
// description += " euros.";
// console.log(description);


// let message = "Bonjour tout le monde";
// let longueur = message.length;
// console.log("La longueur du message est : " + longueur);
// let password = "1234555556";
// if (password.length < 8) {
//   console.log("Le mot de passe est trop court.");
// } else {
//   console.log("Le mot de passe a une longueur adéquate.");
// }

// let chaine = "chabelle";
//     console.log(chaine[0])
//     console.log(chaine[1])
//     console.log(chaine[2])
//     console.log(chaine[3])
//     console.log(chaine[4])
//     console.log(chaine[5])
//     console.log(chaine[6])
//     console.log(chaine[7])

//     let mot = "chabelle";
//  let premierCaractere = mot[0];
// let dernierCaractere = mot[mot.length - 1];
// console.log("Le premier caractère est : " + premierCaractere);
// console.log("Le dernier caractère est : " + dernierCaractere);

let mot = "JavaScript";
let premierCaractere = mot[0];
let dernierCaractere = mot[mot.length - 1];
console.log("Le premier caractère est : " + premierCaractere);
console.log("Le dernier caractère est : " + dernierCaractere);


// let fruits = ["pomme", "banane", "cerise"]; 
// fruits[0] = "avocat"; // Notre tableau vaudra maintenant ["avocat", "banane", "cerise"]
// fruits[5] = "papaye";
// console.log(fruits)

// let fruits = ["pomme", "banane", "cerise"]; 
// const firstElement = fruits.shift();
// console.log(fruits)

// let fruits = ["pomme", "banane", "cerise"]; 
// const count = fruits.unshift("papaye", "ananas");
// console.log (fruits)
// // fruits = ["papaye", "ananas", "pomme", "banane", "cerise"]
// console.log(count); // affiche 5

// let fruits = ["pomme", "banane", "cerise"]; 

// let countArray = fruits.push("avocat"); 

// // frutis = ["pomme", "banane", "cerise", "avocat"] 
// // countArray vaudra 4 (la nouvelle longueur du tableau)

// const count = fruits.push("papaye", "ananas", "mandarine"); 
// // fruits = ["pomme", "banane", "cerise", "avocat", "papaye", "ananas", "mandarine"]



// let fruits = ["pomme", "banane", "cerise"]; 
// fruits.pop();

// // fruits = ["pomme", "banane"]
// console.log(fruits.pop()) // affiche "cerise"



// function wordBlanks(nom, adjectif, verbe, pronom) {
//     // Entrez votre code ci-dessous
//     let result = "";

//     // Entrez votre code ci-dessus
//     return result;
// }

// // Changer les mots ici pour tester les fonctions
// console.log(wordBlanks("chien", "grand", "court", "vite"));

// function wordBlanks() {
//     // Entrez votre code ci-dessous
//     let nom = "boni";
//     let adjectif = "cool";
//     let verbe = " est" ;
//     let pronom = " un";
       
//     let  result = "Le " + adjectif + nom + verbe + pronom + " dans la rue";
//     // Entrez votre code ci-dessus
//     return result;
// }
// console.log (wordBlanks(result))
// // // Changer les mots ici pour tester les fonctions
// // console.log(wordBlanks("chien", "grand", "court", "vite"));



let myList = [
    ["cereal", 3], 
    ["milk", 2],
    ["bananas", 3],
    ["juice", 2],
    ["eggs", 3]
]
// Affichez le premier élément du tableau myList.
// const firstElement = myList.shift();
// console.log( firstElement);
// Affichez la quantité de "milk".
// const mq = myList[1];
// console.log( mq);

// Changez la quantité de "bananas" de 3 à 5.
myList[2][1]= '5' ;
console.log (myList[2][1])
console.log(myList [2])
console.log(myList)
// myList[2]= ' \"bananas", 5 \'' ;
// console.log (myList)

//Remplacez "juice" par "orange juice" tout en gardant la même quantité.
myList[3][0]= 'orange juice' ;
console.log (myList[3][0])
console.log(myList [2])
console.log(myList)


//Ajoutez un nouvel élément ["bread", 1] à la fin du tableau.
const no = myList.push( '["bread", 1] ');
console.log(no);
console.log(myList);

//Supprimez le premier élément du tableau.

const non = myList.shift() ;
console.log(non)
console.log(myList)


