// // const utilisateur = {
// //     nom: "Doe",
// //     prenom: "John"
// // };

// // const nomVal = utilisateur.nom;
// // const prenomVal = utilisateur.prenom;

// // console.log (nomVal ,prenomVal)


// function phoneticLookup(val) {
//     let result = "";
  
//     const lookup = {
//       alpha: "Adams",
//       bravo: "Boston",
//       charlie: "Chicago",
//       delta: "Denver",
//       echo: "Easy",
//       foxtrot: "Frank"
//     };
//     result = lookup[val];
//     return result;
//   }
  
//   console.log(phoneticLookup("charlie"));

  
//   //test

//   function checkForProperty(object, property) {
//     return object.hasOwnProperty(property);
//     }

//     checkForProperty({ top: 'hat', bottom: 'pants' }, 'top'); // true
//     checkForProperty({ top: 'hat', bottom: 'pants' }, 'middle'); // false


//     //esult

//     function checkForProperty(object, property) {
//         return object.hasOwnProperty(property);
//       }
      
//       checkForProperty({ top: "hat", bottom: "pants" }, "top"); // true
//       checkForProperty({ top: "hat", bottom: "pants" }, "middle"); // false
      
//       console.log(checkForProperty({ top: "hat", bottom: "pants" }, "middle"));
      

//       // obket complexes


//       function checkObj(obj, checkProp) {
//         if (obj.hasOwnProperty(checkProp)){
//             return obj[checkProp];
//         } else
//             return "Not Found";
            
//     }


//     // tableau imprication 

//     const myPlants = [
//         {
//             type: "flowers",
//             list: [
//                 "rose",
//                 "tulip",
//                 "dandelion"
//             ]
//         },
//         {
//             type: "trees",
//             list: [
//                 "fir",
//                 "pine",
//                 "birch"
//             ]
//         }
//     ];
    
//     const secondTree = myPlants[1].list[1];
    
//     console.log(secondTree)




//     // collection de disques

//     const recordCollection = {
//         2548: {
//           albumTitle: "Slippery When Wet",
//           artist: "Bon Jovi",
//           tracks: ["Let It Rock", "You Give Love a Bad Name"]
//         },
//         2468: {
//           albumTitle: "1999",
//           artist: "Prince",
//           tracks: ["1999", "Little Red Corvette"]
//         },
//         1245: {
//           artist: "Robert Palmer",
//           tracks: []
//         },
//         5439: {
//           albumTitle: "ABBA Gold"
//         }
//       };
      
//       function updateRecords(records, id, prop, value) {
//         if (value === "") {
//           delete records[id][prop];
//         } else if (prop === "tracks") {
//           records[id][prop] = records[id][prop] || [];
//           records[id][prop].push(value);
//         } else {
//           records[id][prop] = value;
//         }
//         return records;
//       }
      
//       updateRecords(recordCollection, 5439, "artist", "ABBA");
      
//       console.log(recordCollection);

      

//       //boucle -whiles -for


// //       const myArray = [];
// //         // ...

// // for (let i = 1; i <= 5; i++) {
// //         myArray.push(i);
// //         }

// // console.log(myArray)

// // const ourArray = [];
// // let i = 0;

// // while (i < 5) {
// // ourArray.push(i);
// // i++;

// // }


// // parité en js 

// // const ourArray = [];

// //     for (let i = 0; i < 10; i += 2) {
// //         ourArray.push(i);
// //     }

// //     const myArray = [];
        
// //     for (let i = 1; i <= 9; i += 2) {
// //         myArray.push(i);
// //     }


//     // compter a l'envers

//     const ourArray = [];

//     for (let i = 10; i > 0; i -= 2) {
//     ourArray.push(i);
//     }


//     const myArray = [];
//     //for imbriqué     
//     for (let i = 1; i <= 9; i -= 2) {
//         myArray.push(i);
//     }

//     function multiplyAll(arr) {
//       let product = 1;
  
//       for (let i = 0; i < arr.length; i++) {
//           for (let j = 0; j < arr[i].length; j++) {
//               product *= arr[i][j];
//               }
//           }
//       return product;
//   }
  
//   multiplyAll([[1, 2], [3, 4], [5, 6, 7]]);


//   /// do while

//   const ourArray = [];
//   let i = 0;

//   do {
//       ourArray.push(i);
//       i++;
//   } while (i < 5);





//   // peo look profil


  const contacts = [
    {
      firstName: "Akira",
      lastName: "Laine",
      number: "0543236543",
      likes: ["Pizza", "Coding", "Brownie Points"]
    },
    {
      firstName: "Harry",
      lastName: "Potter",
      number: "0994372684",
      likes: ["Hogwarts", "Magic", "Hagrid"]
    },
    {
      firstName: "Sherlock",
      lastName: "Holmes",
      number: "0487345643",
      likes: ["Intriguing Cases", "Violin"]
    },
    {
      firstName: "Kristian",
      lastName: "Vos",
      number: "unknown",
      likes: ["JavaScript", "Gaming", "Foxes"]
    }
  ];
  
  function lookUpProfile(name, prop) {
    for (let i = 0; i < contacts.length; i++) {
      if (contacts[i].firstName == name) {
        if (contacts[i].hasOwnProperty(prop)) {
          return contacts[i][prop];
        } else {
          return "No such property";
        }
      }
    }
    return "No such contact";
  }
  console.log(lookUpProfile("Akira", "likes"));
  console.log(contacts)

  
//   //pas compris😢🤦‍♂️




//FRACTION AL2ATOIRE

console.log(Math.random()) // => génération de nombre aléatoire compris entre 0 et 1(exclu)
console.log(Math.floor(Math.random() * (15 - 10))) // => génération de nombre entier aléatoire compris entre 0 et 5 (exclu. 5 étant la différence entre 15 et 10)
console.log(Math.floor(Math.random() * (15 - 10 + 1))) // => génération de nombre entier aléatoire compris entre 0 et 5 (5 inclu)
console.log(Math.floor(Math.random() * (15 - 10 + 1)) + 10) // => génération de nombre entier aléatoire compris entre 10 (0 + 10) et 15 (5 + 10) avec '15' inclu dans l'intervalle

//TERNAIRE


    //Exemple 1
    let age = 18;
    let message = age >= 18 ? "Vous êtes majeur" : "Vous êtes mineur";
    console.log(message); // Affiche : Vous êtes majeur

    //Exemple 2
    let nombre = 10;
    let parite = nombre % 2 === 0 ? "pair" : "impair";
    console.log(`Le nombre ${nombre} est ${parite}.`); // Affiche : Le nombre 10 est pair.

//TRI TERNAIRE


    /**
     * Exemple 1
     * Considérons un exemple où nous attribuons des notes en fonction d'un score :
     */
    let score = 50;
    let grade = score >= 90 ? "A"
            : score >= 80 ? "B"
            : score >= 70 ? "C"
            : score >= 60 ? "D"
            : "F";

    console.log(`La note est ${grade}.`); // Affiche : La note est F.




    
 //
 const tab = [ "fff",true , false ,"dodo"]
 let atb = []
for (let i =0 ; i < tab.length ; i++)

  if 
     (tab[i] = typeof Boolean )
       {
        atb =tab[i]
         console.log ( i , atb)
     }
  

  // console.log( i , atb)

