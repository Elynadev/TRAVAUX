// let bg = document.querySelector('.boule');
// let taille= 200 ;
// console.log(bg)

// // function déplacer ( event) {
// //     console.log(event.code);
   

// // }

// function action(event) 
//  {
//  console.log(event.code);
//  if(event.code == 'H') {

    
//  }
    
//     }
// }

// document.addEventListener('keydown', action) 
function myMove() {
    let id = null;
    const elem = document.getElementById("animate");   
    let pos = 0;
    clearInterval(id);
    id = setInterval(frame, 5);
    function frame() {
      if (pos == 350) {
        clearInterval(id);
      } else {
        pos++; 
        elem.style.top = pos + "px"; 
        elem.style.left = pos + "px"; 
      }
    }
  }


  function myLeft() {
    let id = null;
    const elem = document.getElementById("animate");   
    let pos = 0;
    clearInterval(id);
    id = setInterval(frame, 5);
    function frame() {
      if (pos == 350) {
        clearInterval(id);
      } else {
        pos++; 
        elem.style.top = pos - "px"; 
        elem.style.left = pos +"px"; 
      }
    }
  }

  function myR() {
    let id = null;
    const elem = document.getElementById("animate");   
    let pos = 0;
    clearInterval(id);
    id = setInterval(frame, 5);
    function frame() {
      if (pos == 350) {
        clearInterval(id);
      } else {
        pos++; 
        elem.style.top = pos - "px"; 
        elem.style.left = pos +"px"; 
      }
    }
  }


  function myH() {
    let id = null;
    const elem = document.getElementById("animate");   
    let pos = 350;
    clearInterval(id);
    id = setInterval(frame, 5);
    function frame() {
      if (pos == 0) {
        clearInterval(id);
      } else {
        pos++; 
        elem.style.top = pos - "px"; 
        elem.style.left = pos - "px"; 
      }
    }
  }