// // syntaxe fonction 
// function nomDeLaFonction() {
//     // Corps de la fonction
//     console.log('Un sourire ne coûte rien mais il crée beaucoup.');
//   }
//   nomDeLaFonction();

//   //paramètre et fonction 
//   function additionner(a, b) {
//     console.log(a + b);
//   }
//   additionner(3,4)

//   // Définition de la fonction avec des paramètres
// function salut(prenom, nom) {
//     console.log("Bonjour, " + prenom + " " + nom + "!");
//   }
//   // Appel de la fonction avec des arguments
//   salut ("karaba", "Design"); 
  
//   //Objectif : Créez une fonction qui prend deux nombres en paramètres et affiche leur somme.
 
//   function somme(a, b) {
     
//      console.log (a+ b);
//   }

//   somme(8 ,5);

//   //Objectif : Créez une fonction qui convertit une température de Celsius en Fahrenheit. La formule de conversion est (Celsius * 9/5) + 32.

//   function celsuis (température){
//     let x =  température* 9/5+5 ;
//      console.log(x) 

//   }
//   celsuis(37)
// //    let x = celsuis(37);
// //    console.log (x)
// //    console.log ("votre température est de " + x)

// //Objectif : Créez une fonction qui prend une chaîne de caractères en paramètre et retourne cette chaîne inversée.
 
 

//  // pal

// //  function palindrome(s ,String)
// // {
// //   if (length(s) < 2){

// //   }

// //   else
// //     if (s[1] = s[length(s)]) {
// //         palindrome(copy(s, 2, length(s) - 2))
// //     }
  
// //     else {
// //         palindrome = false; 
// //     }
   

// // }

// // palindrome(bonjour)

// // split(): cette méthode divisera
// //  la chaîne en un tableau de caractères.
// // reverse(): cette méthode inverse
// //  tous les éléments d’un tableau.
// // join(): Cette méthode joint tous 
// // les éléments du tableau pour 
// // créer une chaîne de caractères.


// //inversement
// // function inversée(chaine) {
// //  let inv =chaine.split("").reverse("").join("");
// //  console.log (inv);


// // }
// //   inversée ("bonjour")


// //   //voyelle


// let pays = "France";

// function afficherPays() {
//   let pays = "Canada";
//   console.log("Le pays à l'intérieur de la fonction est : " + pays); // Attendu : "Canada"
// }

// afficherPays();
// console.log("Le pays à l'extérieur de la fonction est : " + pays); // Attendu : "France"



// //exercice1Objectif : Déclarez une variable globale et utilisez-la dans une fonction.

// let ville = "cotonou";

// function villes() {

//   console.log("bonjour  " + ville); 
// }
// villes()


// //bjectif : Déclarez une variable locale à l'intérieur d'une fonction et tentez de l'accéder à l'extérieur de la fonction.

// function afficher() {
//   let ba = "beaucoup";
//   console.log("ils sont  "   +  ba);
// }

// afficher();


// // Exemple

// let sum = 0;
// function addThree() {
//     sum = sum + 3;
// }

// addThree();

// //


// function addFive() {
//   sum += 5; // ou pourrait écrire: sum = sum + 5;
// }

// console.log(addFive()); // on vérifie ce que retourne addFive()
// //
// let changed = 0;

// function change(num) {
//     return (num + 5) / 3;
// }

// changed = change(10);

// let processed = 0;

// function processArg(num) {
//     return (num + 3) / 5;
// }
 
// console.log(changed)
// console.log(change)




// //

// // function nextInLine(arr, item) {
  
// //   return item;
// // }

// // let testArray = [1, 2, 3, 4, 5];

// // console.log("Avant: " + JSON.stringify(testArray));
// // console.log(nextInLine(testArray, 6));
// // console.log("Après: " + JSON.stringify(testArray));


// function nextInLine(arr, item) {
//   // Vous pouvez modifiez le code ci-dessous
//   return item;
// }

// let testArray = [1, 2, 3, 4, 5];

// console.log(nextInLine(testArray, 6)); // renvoie 6

// console.log("Avant: " + JSON.stringify(testArray)); // renvoie [1, 2, 3, 4, 5]
// console.log(nextInLine(testArray, 6)); // renvoie 6
// console.log("Après: " + JSON.stringify(testArray));

// //
// function isStudentOnHighfive() {
//   return true; // ou return false;
// }

// isStudentOnHighfive();


// //

// let number = 5;

//     if (number > 0) {
//         console.log("Le nombre est positif.");
//     }






//     //

//     console.log(5 == '5'); // Affiche true car '5' est converti en 5 avant comparaison
// console.log(true == 1); // Affiche true car true est converti en 1 avant comparaison
// console.log(false == 0); // Affiche true car false est converti en 0 avant comparaison


// //

// let age = 25;
//     let hasPermit = true;

//     if ((age >= 18 && age <= 65) || hasPermit) {
//         console.log("Vous êtes autorisé à conduire.");
//     } 

//     //
//     const val = 7;

//     if(val < 10) {
//         console.log("Moins que 10");
//     } else if (val < 5) {
//         console.log("Moins que 10");
//     } else {
//         console.log("supérieur ou égal à 10");    
//     };

//     if(val < 5) {
//       console.log("Moins que 5");
//   } else if (val < 10) {
//       console.log("Moins que 10");
//   } else {
//       console.log("supérieur ou égal à 10");   
      
      
//   }

//   //Golf Code

//       // Scores pour chaque trou
//       const scores = [4, 3, 5];

//       // Par pour chaque trou
//       const par = [4, 3, 5];
  
//       // Vérification pour le trou 1
//       const difference1 = scores[0] - par[0];
//       if (difference1 < 0) {
//           console.log("Trou 1: Vous êtes " + Math.abs(difference1) + " coup(s) en dessous du par.");
//       } else if (difference1 > 0) {
//           console.log("Trou 1: Vous êtes " + difference1 + " coup(s) au-dessus du par.");
//       } else {
//           console.log("Trou 1: Vous êtes au par pour ce trou.");
//       }
  
//       // Vérification pour le trou 2
//       const difference2 = scores[1] - par[1];
//       if (difference2 < 0) {
//           console.log("Trou 2: Vous êtes " + Math.abs(difference2) + " coup(s) en dessous du par.");
//       } else if (difference2 > 0) {
//           console.log("Trou 2: Vous êtes " +  difference2 + " coup(s) au-dessus du par.");
//       } else {
//           console.log("Trou 2: Vous êtes au par pour ce trou.");
//       }
  
//       // Vérification pour le trou 3
//       const difference3 = scores[2] - par[2];
//       if (difference3 < 0) {
//           console.log("Trou 3: Vous êtes " + Math.abs(difference3) + " coup(s) en dessous du par.");
//       } else if (difference3 > 0) {
//           console.log("Trou 3: Vous êtes " +  difference3   + " coup(s) au-dessus du par.");
//       } else {
//           console.log("Trou 3: Vous êtes au par pour ce trou.");
//       } 


//       //switch

//       let jour = 3;
//       let nomJour;
  
//       switch (jour) {
//       case 1:
//           nomJour = "Lundi";
//           break;
//       case 2:
//           nomJour = "Mardi";
//           break;
//       case 3:
//           nomJour = "Mercredi";
//           break;
//       case 4:
//           nomJour = "Jeudi";
//           break;
//       case 5:
//           nomJour = "Vendredi";
//           break;
//       case 6:
//           nomJour = "Samedi";
//           break;
//       case 7:
//           nomJour = "Dimanche";
//           break;
//       default:
//           nomJour = "Jour invalide";
//       }
  
//       console.log("Aujourd'hui, c'est " + nomJour + ".");

      
//  // switch

//  let nombre = 5;
// let categorie;

// switch (nombre) {
//   case 1:
//   case 2:
//   case 3:
//     categorie = "Faible";
//     break;
//   case 4:
//   case 5:
//   case 6:
//     categorie = "Moyen";
//     break;
//   default:
//     categorie = "Élevé";
// }

// console.log("Le nombre " + nombre + " est de catégorie : " + categorie + ".");


// // boléén et fonction

// function estSuperieur(a, b) {
//   if (a > b) {
//       return true
//   }else {
//       return false
//   }
// }

// console.log(estSuperieur(6, 4))



//Retourner un Résultat de Calcul
function sum(a, b) {
  let sum = a+b;
   return sum;

}
console.log (sum(2,5));


//Vérifier si un Nombre est Pair

function pairr(a) {
  if (a % 2 == 0) {
      return true
  }else {
      return false
  }
}

console.log(pairr(3))


// pour eviter d'aller jusqu'a a la fin de la fonction 

function estSuperieur(a, b) {
  if (b === 0) {
      return "Calcule impossible";
  }

  return a / b
}

console.log(estSuperieur(6, 0)) //affiche "Calcule impossible" dans la console









