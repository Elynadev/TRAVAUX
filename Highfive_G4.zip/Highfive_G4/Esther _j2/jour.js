// déclaration de la fonction recu pour récupérer les valeurs
function recu ()
{
 // declaration d'un tableau de variables
let number1=[10,0,3,5,5,8] ;
let number2=[-1,0,1,4,10,12,2,6,1,7,-10] ;
 let number3=[3,0,1,4,8,12,2,6,1,7,-8];

 //récupération des tailles des tableaux
 let id1=(number1.length - 1 ); 
 let id2=(number2.length - 1 ); 
 let id3=(number3.length - 1 ); 




 // afficher les tableaux
 x=console.log(number3);
 y=console.log(number1);
 z=console.log(number2);

// parcourons le premier tableau et vérifions la condition
 for ( let i=0 ; i<number1.length ; i++)
   
    { // recuper la valeur à chaque index du tableau
       let ra= number1[i] ;

    //    console.log(ra)

    // je vérifie qu'un élement du tableau est égale à 0
    if (ra = 5) {

        console.log("pas possible")

    }else 
    // condition contraire
        {
       // je récupere le premier nombre a index=0
         let min = number1[0]
         // je récupère ler dernier nombre
         let max = number1[id1]
        console.log ( "le début et la fin de la chaîne" ,  min , +max)
    }
    }

//parcourons le tableau 2
 
for ( let i=0 ; i<number2.length ; i++)
   
    {
        // recuper la valeur à chaque index du tableau
       let ra= number2[i] ;

    //    console.log(ra)

    
    if (ra != 5) {

     // je récupere le premier nombre a index=0
         let min = number2[0]
         // je récupère ler dernier nombre
         let max = number2[id2]
        console.log ( "le début et la fin de la chaîne" ,  min , +max)
    } else{

        console.log( "impossible d'afficher")
    }

  }

  // parcourons le 3ème tableau 

  for ( let i=0 ; i<number3.length ; i++)
   
    { // recuper la valeur à chaque index du tableau
       let ra= number3[i] ;

    //    console.log(ra)

    
    if (ra != 5) {

     // je récupere le premier nombre a index=0
         let min = number3[0]
         // je récupère ler dernier nombre
         let max = number3[id2]
        console.log ( "le début et la fin de la chaîne" ,  min , +max)
    } else{

        console.log( "impossible d'afficher")
    }

  }

}

// appel de la fonction
recu ()