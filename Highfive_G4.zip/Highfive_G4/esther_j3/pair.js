function  multiple( )
{
 // tableau de nombre inférieur à 9
    let number= [ 0,1,2,3,4,5,6,7,8,9];
    console.log (number);

  let somme=0
  let i=0;
  // parcourir le tableau tout en vérifiant si le nombre est supérieur ou égal à 0 puis éffectuer la sommme :nombre inférieur à 10
  for ( let i=0; i <10 ; i++  )
      {
      if  ( number[i]<0)
             {
               number[i]=0;
             }
        if ( number[i] >0 && number[i] % 3 === 0 || number[i] % 5 === 0)
            {
                somme  = somme + number[i];
              
              console.log( "le résultat est " +somme);
            }
        
        
      }
}
multiple( )

