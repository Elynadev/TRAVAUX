<script setup>
import  { ref } from 'vue';
import { defineProps } from 'vue';
 const props = defineProps({
    todos: {
        type: Array,
        required: true
        }
})

console.log(props.todos);


const updateTodo = (element) => {
   console.log (todo)
};


emit ('sendTodo')


</script>

<template>
  <ul>
  <li v-for=" (todo, index) in todos " :key="index" @click="updateTodo(todo)">
    {{  todo.titre }}
  </li>
  
</ul>
 </template>



<style scoped>


</style>