<script setup>
import  { ref } from 'vue';
const showBtn = ref(true);
const task= ref ('')
const emit  = defineEmits(['request']);
const sendlist = (el) => {
    console.log(el);
    emit ( 'request', el)
}


</script>

<template>
<div>
      <input  v-model="task" type="text" id="inputTache"/>
      <br>
      <button v-if="showBtn" @click="sendlist(task)">Ajouter</button>
      <button v-else>Editer</button>
</div>
</template>

<style scoped>

</style>