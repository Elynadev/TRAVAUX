<script setup>

import { ref } from 'vue'

import Formulaire from "./components/Formulaire.vue";
import ListTodo from './components/ListTodo.vue';

const todos = ref([
  {titre:"Finir mon exo js", statut:"En cours", categorie:"Cours"},
  {titre:"Finir mon exo Vue", statut:"Terminé", categorie:"Cours"},
  {titre:"Faire du body attack", statut:"En cours", categorie:"Sport"}
])

const addTodo =(paramètre) =>{
  todos.value.push ({titre: paramètre, statut: " " ,catégorie: " "});
  console.log(paramètre);

}
console.log()


</script>

<template>
<h1>Bienvenu(e) dans l'univers des tâches</h1>

 <Formulaire @request="addTodo"> </Formulaire>

 <ListTodo :todos = "todos"></ListTodo>

</template>




<style>

</style>