 problème 

 Ce chiffrement consiste à prendre chaque caractère d’une chaîne et à multiplier leurs codes de caractères par 6.

Par exemple, 'Hello World !' deviendrait 'ưɞʈʈʚÀȊʚʬʈɘÆ'.

Vous devez écrire deux fonctions :
'encode' pour encoder une chaîne donnée,
'decode' pour décoder une chaîne donnée.


solution 

* DEFINIR LA CHAINE DE CARACTEREE
*
récupérer la valeur de chaque caractère et les mettres dans un tableau 
* parcourir le tableau  en recupérant l'ancienne valeur pour décoder ou coder puis affectez la nouvelle valeur après encodage .
*concatenez les élements du tavleau et les afficher 

proposition de code**//
 pour enconder
// function encode( str) {
  
//   let p= ["Hello word"] ;
//    let len = p [0].length;
  
//    for (let i = 0 ; i < len -1 ; i++)
//      {
//        let p= [ "Hello"] ;
//        let len = p [0].length;
  
//        let table =  Array.from(p[i]) ;    
       
       

//           console.log (table );
//         let code = table[0].charCodeAt () *6;
//        let code1 = table[1].charCodeAt () *6 ;
//        let code2 = table[2].charCodeAt () *6;
//        let code3 = table[3].charCodeAt ()* 6;
//        let code4 = table[4].charCodeAt ()* 6;
//        console.log (code,code1,code2,code3,code4 )
       
//          let ecode=  String.fromCharCode(code);
//          let ecode1= String.fromCharCode(code1);
//          let ecode2=String.fromCharCode(code2);
//          let ecode3=String.fromCharCode(code3);
//          let ecode4= String.fromCharCode(code4);
//      console.log ( ecode+ecode1+ecode2+ecode3+ecode4)
            
// }
//  }
 pour décoder
// encode ()

function decode(str) {
  
  let p= ["ưɞʈʈʚ"] ;
   let len = p [0].length;
  
   for (let i = 0 ; i < len -1 ; i++)
     {
       let p= [ "ưɞʈʈʚ"] ;
       let len = p [0].length;
  
       let table =  Array.from(p[i]) ;    
       
       

          console.log (table );
        let code = table[0].charCodeAt () / 6;
       let code1 = table[1].charCodeAt () / 6 ;
       let code2 = table[2].charCodeAt ()  / 6;
       let code3 = table[3].charCodeAt () / 6;
       let code4 = table[4].charCodeAt () / 6;
       console.log (code,code1,code2,code3,code4 )
       
         let ecode=  String.fromCharCode(code);
         let ecode1= String.fromCharCode(code1);
         let ecode2=String.fromCharCode(code2);
         let ecode3=String.fromCharCode(code3);
         let ecode4= String.fromCharCode(code4);
     console.log ( ecode+ecode1+ecode2+ecode3+ecode4)
            
}
 }



decode ()